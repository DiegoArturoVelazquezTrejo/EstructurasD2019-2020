module Practica6 where

-- 1
belongs :: Int -> [Int] -> Bool
belongs a [] = False
belongs a (x:xs)= if(a == x) then True else belongs a xs

-- 2
get_nth :: Int -> [a] -> a
get_nth n [] = error "No hay elementos"
get_nth 0 (x:xs) = x
get_nth n (x:xs) = get_nth (n-1) xs

-- 3
delete_nth :: Int -> [a] -> [a]
delete_nth n [] = error "La lista es vacía"
delete_nth 0 (x:xs) = xs
delete_nth n (x:xs) = [x]++(delete_nth (n-1) xs)

-- 4
delete_all :: (Eq a) => a -> [a] -> [a]
delete_all a [] = []
delete_all a (x:xs) = if(a == x) then (delete_all a xs) else [x]++(delete_all a xs)

-- 5
filterLab :: (a -> Bool) -> [a] -> [a]
filterLab p [] = []
filterLab p (x:xs) =if(p x) then [x]++ (filterLab p xs) else filterLab p xs



data BTree a = Empty | Node a (BTree a) (BTree a) deriving Show

leaf a = Node a Empty Empty


-- num_elem (Node 10(Node 5(Node 2 Empty Empty) (Node 7 Empty Empty))(Node 15 ( Node 12 Empty Empty) (Node 22 Empty Empty)))
-- 6
num_elem :: BTree a -> Int
num_elem Empty = 0
num_elem (Node a b c) = 1 + (num_elem b) + (num_elem c)


-- num_leaves ( Node 10 ( Node 5 ( Node 2 Empty Empty ) ( Node 7 Empty Empty ) )( Node 15 ( Node 12 Empty Empty ) (Node 22 Empty Empty )))
-- 7
num_leaves :: BTree a -> Int
num_leaves (Node a Empty Empty) = 1
num_leaves (Node a b c) = (num_leaves b) + (num_leaves c)

-- belongsT 88 ( Node 10 ( Node 5 ( Node 2 Empty Empty ) ( Node 7 Empty Empty ) )( Node 15 ( Node 12 Empty Empty ) ( Node 22 Empty Empty ) ) )
--belongsT 7 ( Node 10 ( Node 5 ( Node 2 Empty Empty ) ( Node 7 Empty Empty ) )( Node 15 ( Node 12 Empty Empty ) ( Node 22 Empty Empty ) ) )
-- 8
belongsT :: (Eq a) => a -> BTree a -> Bool
belongsT z (Node a Empty Empty) = if(z == a) then True else False
belongsT z (Node a b c) = if(z == a) then True else (belongsT z b) || (belongsT z c)

-- 9
preorder :: BTree a -> [a]
preorder Empty = []
preorder (Node a b c) = [a] ++ (postorder b) ++ (postorder c)

-- 10
inorder :: BTree a -> [a]
inorder Empty = []
inorder (Node a b c) = (inorder b) ++ [a] ++ (inorder c)

-- 11
postorder :: BTree a -> [a]
postorder Empty = []
postorder (Node a b c) = (postorder b) ++ (postorder c) ++ [a]


-- add 20 ( Node 10 ( Node 5 ( Node 2 Empty Empty ) ( Node 7 Empty Empty ) )( Node 15 ( Node 12 Empty Empty ) ( Node 22 Empty Empty ) ) )
-- 12
add :: (Eq a, Ord a) => a -> BTree a -> BTree a
add a Empty = (Node a Empty Empty)
add z (Node a b c) = if(belongsT z (Node a b c)) then (Node a b c) else if(z < a) then (Node a (add z b) c) else (Node a b (add z c))


-- 13
delete :: (Eq a, Ord a) => a -> BTree a -> BTree a
delete z (Node a Empty Empty) = if(z == a) then Empty else (Node a Empty Empty)
delete z (Node a Empty c) = if(a == z) then c else (Node a Empty (delete z c))
delete z (Node a b Empty) = if(a == z) then b  else (Node a (delete z b) Empty)
delete z (Node a (Node x y q) (Node t u v)) = if(z == a) then (Node x (delete z (Node a y q)) (Node t u v))else
  if (z < a) then (Node a (delete z (Node x y q)) (Node t u v))
  else (Node a (Node x y q) (delete z (Node t u v)))
