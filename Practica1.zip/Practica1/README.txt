Diego Arturo Velázquez Trejo 317227257
Daniel Ricardo Díaz Hernández 312238795
